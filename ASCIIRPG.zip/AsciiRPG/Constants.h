#pragma once
#define SCREEN_WIDTH 50
#define SCREEN_HEIGHT 50
#define TICK_INTERVAL 60
#define TICK_TIME ((1.0f / TICK_INTERVAL) * 1000)
